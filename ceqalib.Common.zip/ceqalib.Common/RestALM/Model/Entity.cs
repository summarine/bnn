﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ceqalib.Common.RestALM.Model
{
    [Serializable, XmlRootAttribute("Entity")]
    public class Entity
    {
        private string type;
        private Field field;
        private List<Field> fields;

        [XmlAttribute("Type")]
        public string Type
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }

        [XmlArray("Fields")]
        
        [XmlArrayItem("Field")]
        public List<Field> _Fields
        {
            get
            {
                return fields;
            }
            set
            {
                fields = value;
            }
        }

        public Entity()
        {
        }

        protected Entity(Entity entity) : this()
        {
            fields = entity.fields;
            type = entity.type;
        }

        public List<Field> GetFields()
        {
            if (fields == null)
            {
                fields = new List<Field>();
            }
            return fields;
        }

        public Field GetField(string name)
        {
            foreach (var field in GetFields())
            {
                if (field.Name.Equals(name))
                {
                    return field;
                }
            }
            return null;
        }

        public void SetFieldValue(string name, string value)
        {
            Field field = GetField(name);
            if (field == null)
            {
                field = new Field(name);
                GetFields().Add(field);
            }
            field.Value = value;
        }

        public string GetFieldValue(string name)
        {
            Field field = GetField(name);
            return field != null ? field.Value: null;
        }

        public virtual Entity PrepForUpdate()
        {
            Entity newEntity = new Entity();
            newEntity.type = type;
            newEntity.Id = Id;
            return newEntity;
        }

        public void RemoveField(string name)
        {
            List<Field> fields = GetFields();
            foreach (var it in fields)
            {
                if (name.Equals(it.Name))
                {
                    fields.Remove(it);
                    break;
                }
                    
            }
        }

        public virtual void ClearBeforeUpdate()
        {
            RemoveField("id");
        }

        public string Id
        {
            get
            {
                return GetFieldValue("id");
            }
            set
            {
                SetFieldValue("id", value.ToString());
            }
        }

        public string ParentId
        {
            get
            {
                return GetFieldValue("parent-id");
            }
            set
            {
                SetFieldValue("parent-id", value.ToString());
            }
        }   
       
    }
}
