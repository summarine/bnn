﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ceqalib.Common.RestALM.Model
{
    public class TestSetFolder: Entity
    {
        public TestSetFolder(Entity entity)
            : base()
        {

        }

        public TestSetFolder()
        {
            base.Type = "test-set-folder";
        }

        public string TestSetFolderId
        {
            get
            {
                return GetFieldValue("id");
            }
            set
            {
                SetFieldValue("id", value);
            }
        }

        public string TestSetFolderCycle
        {
            get
            {
                return GetFieldValue("assign-rcyc");
            }
            set
            {
                SetFieldValue("assign-rcyc", value);
            }
            
        }
    }
}
