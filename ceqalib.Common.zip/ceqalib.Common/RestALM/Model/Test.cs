﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ceqalib.Common.RestALM.Model
{    
    public class Test : Entity
    {
         public Test(Entity entity): base() 
         {
        
         }

        public Test() {
            base.Type = "test";
        }

        public string Priority
        {
            get
            {
                return GetFieldValue("user-08");
            }
            set
            {
                SetFieldValue("user-08", value);
            }

        }

        public string ALMProject
        {
            get
            {
                return GetFieldValue("user-09");
            }
            set
            {
                SetFieldValue("user-09", value);
            }
        }

        public string TestPhase
        {
            get
            {
                return GetFieldValue("user-02");
            }
            set
            {
                SetFieldValue("user-02", value);
            }
        }
        public string Application
        {
            get
            {
                return GetFieldValue("user-01");
            }
            set
            {
                SetFieldValue("user-01", value);
            }
        }

        public string ALMDomain
        {
            get
            {
                return GetFieldValue("user-05");
            }
            set
            {
                SetFieldValue("user-05", value);
            }
        }
        public string Status
        {
            get
            {
                return GetFieldValue("status");
            }
            set
            {
                SetFieldValue("status", value);
            }
        }

        public string Id
        {
            get
            {
                return GetFieldValue("id");
            }
            set
            {
                SetFieldValue("id", value);
            }
        }

        public string Name
        {
            get
            {
                return GetFieldValue("name");
            }
            set
            {
                SetFieldValue("name", value);
            }
        }
        public string SubtypeId
        {
            get
            {
                return GetFieldValue("subtype-id");
            }
            set
            {
                SetFieldValue("subtype-id", value);
            }
        }

        public string Description
        {
            get
            {
                return GetFieldValue("description");
            }
            set
            {
                SetFieldValue("description", value);
            }
        }

        public string Automatable
        {
            get
            {
                return GetFieldValue("user-04");
            }
            set
            {
                SetFieldValue("user-04", value);
            }

        }
    }
}
