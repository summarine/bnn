﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ceqalib.Common.RestALM.Model
{
    public class Run : Entity
    {
        public const string StatusBlocked = "Blocked";
        public const string StatusFailed = "Failed";
        public const string StatusNA = "N/A";
        public const string StatusNoRun = "No Run";
        public const string StatusNotCompleted = "Not Completed";
        public const string StatusPassed = "Passed";

        public const string TestTypeManual = "hp.qc.run.MANUAL";

        //Entity entity = new Entity();

        public Run(Entity entity):base()
        {

        }

        public Run(){
            base.Type = "run";
        }

        public string TestInstanceId
        {
            get
            {
                return GetFieldValue("testcycl-id");
            }
            set
            {
                SetFieldValue("testcycl-id", value);
            }
        }

        public string TestSetId
        {
            get
            {
                return GetFieldValue("cycle-id");
            }
            set
            {
                SetFieldValue("cycle-id", value);
            }
        }

        public string TestId
        {
            get
            {
                return GetFieldValue("test-id");
            }
            set
            {
                SetFieldValue("test-id", value);
            }
        }
        public string TestConfigId
        {
            get
            {
                return GetFieldValue("test-config-id");
            }
            set
            {
                SetFieldValue("test-config-id", value);
            }
        }

        public string Status
        {
            get
            {
                return GetFieldValue("status");
            }
            set
            {
                SetFieldValue("status", value);
            }
        }

        public string Owner
        {
            get
            {
                return GetFieldValue("owner");
            }
            set
            {
                SetFieldValue("owner", value);
            }
        }

        public string TestType
        {
            get
            {
                return GetFieldValue("subtype-id");
            }
            set
            {
                SetFieldValue("subtype-id", value);
            }
        }
        public string Id
        {
            get
            {
                return GetFieldValue("id");
            }
            set
            {
                SetFieldValue("id", value);
            }
        }

        public string Host
        {
            get
            {
                return GetFieldValue("host");
            }
            set
            {
                SetFieldValue("host", value);
            }
        }

        public string Comments
        {
            get
            {
                return GetFieldValue("comments");
            }
            set
            {
                SetFieldValue("comments", value);
            }
        }


        public string Duration
        {
            get
            {
                return GetFieldValue("duration");
            }
            set
            {
                SetFieldValue("duration", value.ToString());
            }
        }

    }
}
