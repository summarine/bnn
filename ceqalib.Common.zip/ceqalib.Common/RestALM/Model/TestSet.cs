﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ceqalib.Common.RestALM.Model
{
    public class TestSet : Entity
    {
        public TestSet(Entity entity):base()
        {
            
        }

        public TestSet()
        {
            base.Type = "test-set";
        }

        public string TestPhase
        {
            get
            {
                return GetFieldValue("user-02");
            }
            set
            {
                SetFieldValue("user-02", value);
            }
        }
        public string Application
        {
            get
            {
                return GetFieldValue("user-01");
            }
            set
            {
                SetFieldValue("user-01", value);
            }
        }

        public string Status
        {
            get
            {
                return GetFieldValue("status");
            }
            set
            {
                SetFieldValue("status", value);
            }
        }

        public string SubtypeId
        {
            get
            {
                return GetFieldValue("subtype-id");
            }
            set
            {
                SetFieldValue("subtype-id", value);
            }
        }


        public string Name
        {
            get
            {

                return GetFieldValue("name");
            }
            set
            {
                SetFieldValue("name", value);
            }
            
        }

        public string Comment
        {
            get
            {

                return GetFieldValue("comment");
            }
            set
            {
                SetFieldValue("comment", value);
            }

        }


        //public string Id
        //{
        //    get
        //    {
        //        return GetFieldValue("id");
        //    }
        //    set
        //    {
        //        SetFieldValue("id", value);
        //    }
        //}

        public string Description
        {
            get
            {
                return GetFieldValue("description");
            }
            set
            {
                SetFieldValue("description", value);
            }
        }
    }
}
