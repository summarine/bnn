﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ceqalib.Common.RestALM.Model
{
    public class TestInstance : Entity
    {
        public TestInstance(Entity entity):base() 
        {
        
        }

        public TestInstance() {
            base.Type = "test-instance";
        }

        public string TestSetId
        {
            get
            {
                return GetFieldValue("cycle-id");
            }
            set
            {
                SetFieldValue("cycle-id", value);
            }
        }

        public string TestId
        {
            get
            {
                return GetFieldValue("test-id");
            }
            set
            {
                SetFieldValue("test-id", value);
            }
        }

        public string Iterations{
            get
            {
                return GetFieldValue("iterations");
            }
            set
            {
                SetFieldValue("iterations", value);
            }
        }
    }
}
