﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ceqalib.Common.RestALM.Model
{
    public class RunStep : Entity
    {
        
        public RunStep(Entity entity):base(){ }
          
        public RunStep() 
        {
            base.Type = "run-step";
        }

        public  RunStep PrepForUpdate() 
        {
            RunStep newRunStep = new RunStep(base.PrepForUpdate());
            newRunStep.RunId = RunId;
            return newRunStep;
        }

       
        public void ClearBeforeUpdate() 
        {
            RemoveField("parent-id");
            base.ClearBeforeUpdate();
        }

        public int RunId
        {
            get
            {
                return Int32.Parse(GetFieldValue("id"));
            }
            set
            {
                SetFieldValue("id", value.ToString());
            }
        }
        public string Duration
        {
            get
            {
                return GetFieldValue("duration");
            }
            set
            {
                SetFieldValue("duration", value.ToString());
            }
        }

        public string Status
        {
            get
            {
                return GetFieldValue("status");
            }
            set
            {
                SetFieldValue("status", value);
            }
        }

        public string TestId
        {
            get
            {
                return GetFieldValue("test-id");
            }
            set
            {
                SetFieldValue("test-id", value.ToString());
            }
        }

        public string Actual
        {
            get
            {
                return GetFieldValue("actual");
            }
            set
            {
                SetFieldValue("actual", value.ToString());
            }
        }
       
        public string Expected
        {
            get
            {
                return GetFieldValue("expected");
            }
            set
            {
                SetFieldValue("expected", value.ToString());
            }
        }

        public string ParentId
        {
            get
            {
                return GetFieldValue("parent-id");
            }
            set
            {
                SetFieldValue("parent-id", value.ToString());
            }
        }   

    //    public String getComments() {
    //        return getFieldValue("user-template-01");
    //    }
    //
    //    public void setComments(String value) {
    //        setFieldValue("user-template-01", value);
    //    }

        public string ExecutionTime
        {
            get
            {
                return GetFieldValue("execution-time");
            }
            set
            {
                SetFieldValue("execution-time", value.ToString());
            }
        }


        
    }
}
