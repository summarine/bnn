﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Xml.Schema;

namespace ceqalib.Common.RestALM.Model
{
    
    [Serializable, XmlRoot("Field")]
    public class Field
    {
        private string _name;
        private string _value;

        [XmlAttribute("Name")]
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        [XmlElement("Value")]
        public string Value
        {
            get
            {
                return _value;
            }
            set
            {
                _value = value;
            }

        }
        
        

        public Field(){
        }

        public Field(string name): this()
        {
            this.Name = name;
        }

        public Field(string name, string value): this(name)
        {
            this.Value = value;
        }

        public override string ToString()
        {
            return Name + "=" + Value;
        }
    }
}
