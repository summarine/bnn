﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ceqalib.Common.RestALM.Model
{
    public class Attachment :Entity
    {
        public Attachment(Entity entity) : base() 
        {

        }

        public Attachment()
        {
            base.Type = "attachment";
        }


        public string Description
        {
            get
            {
                return GetFieldValue("description");
            }
            set
            {
                SetFieldValue("description", value);
            }
        }

        public string FileSize
        {
            get
            {
                return GetFieldValue("file-size");
            }
            set
            {
                SetFieldValue("file-size", value);
            }
        }

        public string RefType
        {
            get
            {
                return GetFieldValue("ref-type");
            }
            set
            {
                SetFieldValue("ref-type", value);
            }
        }
    }
}
