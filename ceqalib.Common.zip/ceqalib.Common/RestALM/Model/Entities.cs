﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ceqalib.Common.RestALM.Model
{
    [Serializable, XmlRoot("Entities")]
    public class Entities
    {
        private List<Entity> _entities;

        private string total;

        [XmlAttribute("TotalResults")]
        public string TotalResults
        {
            get
            {
                return total;
            }
            set
            {
                total = value;
            }
        }

        [XmlElement("Entity")]
        public List<Entity> _Entities
        {
            get
            {
                return _entities;
            }
            set
            {
                _entities = value;
            }
        }

      
    }
}
