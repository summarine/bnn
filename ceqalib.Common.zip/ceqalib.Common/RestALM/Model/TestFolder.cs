﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ceqalib.Common.RestALM.Model
{
    public class TestFolder: Entity
    {
        public TestFolder(Entity entity)
            : base()
        {

        }

        public TestFolder()
        {
            base.Type = "test-folder";
        }

        public string Id
        {
            get
            {
                return GetFieldValue("id");
            }
            set
            {
                SetFieldValue("id", value);
            }
        }

        public string TestFolderName
        {
            get
            {
                return GetFieldValue("name");
            }
            set
            {
                SetFieldValue("name", value);
            }
        }
    }
}
