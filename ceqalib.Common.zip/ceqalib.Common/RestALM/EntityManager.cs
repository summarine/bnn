﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Collections;
using ceqalib.Common.RestALM.Model;
using ceqalib.Common.Helper;

namespace ceqalib.Common.RestALM
{
   public class EntityManager
    {
        private RestConnector _restConnector;

        public EntityManager(RestConnector con)
        {
            this._restConnector = con;
        }

        public RestConnector _RestConnector
        {
            get
            {
                return _restConnector;
            }
        }

        /// <summary>
        /// Add request header which specify response data format as xml
        /// </summary>
        /// <returns>a dictionary contains standard request header</returns>
        private Dictionary<string, string> PrepareRequestHeaders()
        {
            Dictionary<string, string> requestHeaders = new Dictionary<string, string>();
            requestHeaders.Add("Content-Type", "application/xml");
            requestHeaders.Add("Accept", "application/xml");
            return requestHeaders;
        }

        /// <summary>
        /// create an entity
        /// </summary>
        /// <param name="entitiesUrl"></param>
        /// <param name="entity"></param>
        /// <returns></returns>
        public Entity CreateEntity(string entitiesUrl, Entity entity)
        {
            string entityXml = XmlHelper.Instance.ToXml(entity);
            string bodyType = "application/xml";
            var response = _RestConnector.LanuchPostRequest(entitiesUrl, entityXml,bodyType, PrepareRequestHeaders());
            string createdEntityXml = response.Content.ToString();

            return XmlHelper.Instance.FromXml<Entity>(createdEntityXml);
        }
        /// <summary>
        /// create a file 
        /// </summary>
        /// <param name="entityUrl"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public Entity UploadFile(string entityUrl, string path)
        {
            Dictionary<string, string> requestHeaders = new Dictionary<string, string>();
            requestHeaders.Add("Content-Type", "application/octet-stream");
            requestHeaders.Add("Slug", Path.GetFileName(path));
            //requestHeaders.Add("Accept", "text/html,application/xhtml+xml,application/xml");
            string bodyType = "application/octet-stream";
            string data = File.ReadAllText(path);
            var response = _RestConnector.LanuchPostRequest(entityUrl, data,bodyType, requestHeaders);
            string createdEntityXml = response.Content.ToString();

            return XmlHelper.Instance.FromXml<Entity>(createdEntityXml);
        }

        /// <summary>
        /// update entity
        /// </summary>
        /// <param name="entityUrl"></param>
        /// <param name="entity"></param>
        /// <returns>an entity</returns>
        public Entity UpdateEntity(string entityUrl, Entity entity)
        {
            entity.ClearBeforeUpdate();
            string entityXml = XmlHelper.Instance.ToXml(entity);
            Dictionary<string, string> requestHeaders = new Dictionary<string, string>();
            requestHeaders.Add("Content-Type", "application/xml");
            string bodyType = "application/xml";
            var response = _RestConnector.LanuchPutRequest(entityUrl, entityXml,  bodyType, requestHeaders);
            string updatedEntityXml = response.Content.ToString();

            return XmlHelper.Instance.FromXml<Entity>(updatedEntityXml);
        }
        /// <summary>
        /// delete an entity
        /// </summary>
        /// <param name="entityUrl"></param>
        public void DeleteEntity(string entityUrl)
        {
            Dictionary<string, string> requestHeaders = new Dictionary<string, string>();

            _RestConnector.LanuchDeleteRequest(entityUrl, requestHeaders);
        }

        /// <summary>
        /// select an entity what you want
        /// </summary>
        /// <param name="entitiesUrl"></param>
        /// <param name="query"></param>
        /// <returns>a list of entity</returns>
        public List<Entity> SelectEntities(string entitiesUrl, string query)
        {
            Dictionary<string, string> requestHeaders = PrepareRequestHeaders();
            var response = _RestConnector.LanuchGetRequest(entitiesUrl, query, requestHeaders);
            String entitiesXml = response.Content.ToString();
            Entities entities = XmlHelper.Instance.FromXml<Entities>(entitiesXml);
            return entities._Entities;
        }

        public List<Entity> SelectEntities(string entitiesUrl)
        {
            Dictionary<string, string> requestHeaders = PrepareRequestHeaders();
            var response = _RestConnector.LanuchGetRequest(entitiesUrl,"", requestHeaders);
            String entitiesXml = response.Content.ToString();
            Entities entities = XmlHelper.Instance.FromXml<Entities>(entitiesXml);
            return entities._Entities;
        }

        /// <summary>
        /// select entity by entity url
        /// </summary>
        /// <param name="entitiesUrl"></param>
        /// <returns></returns>
        public Entity SelectEntity(string entitiesUrl)
        {
            Dictionary<string, string> requestHeaders = PrepareRequestHeaders();
            var response = _RestConnector.LanuchGetRequest(entitiesUrl, "", requestHeaders);
            String entitiesXml = response.Content.ToString();

            return XmlHelper.Instance.FromXml<Entity>(entitiesXml);
        }

        /// <summary>
        /// select entity by entity url
        /// </summary>
        /// <param name="entitiesUrl"></param>
        /// <returns></returns>
        public Entity SelectEntity(string entitiesUrl,string query)
        {
            Dictionary<string, string> requestHeaders = PrepareRequestHeaders();
            var response = _RestConnector.LanuchGetRequest(entitiesUrl, query, requestHeaders);
            String entitiesXml = response.Content.ToString();

            return XmlHelper.Instance.FromXml<Entity>(entitiesXml);
        }

        /// <summary>
        /// get test set by testset id
        /// </summary>
        /// <param name="testSetId"></param>
        /// <returns>a testSet object</returns>
        public TestSet GetTestSet(int testSetId)
        {
            string testSetUrl = _RestConnector.BuildEntityUrl("test-set", testSetId);
            Entity entity = SelectEntity(testSetUrl);
            return new TestSet(entity);
        }

        private TestSet GetTestSet(string testSetName, string parentId)
        {
            string testSetUrl = _RestConnector.BuildEntityCollectionUrl("test-set");
            string query = "query={name[" + testSetName + "];parent-id[" + parentId + "]}";
            Entity entity = SelectEntity(testSetUrl,query);
            return new TestSet(entity);
        }

        /// <summary>
        /// get a test instance list by providing a testset id
        /// </summary>
        /// <param name="testSetId"></param>
        /// <returns>a list of testInstance</returns>
        public List<TestInstance> GetTestInstanceList(string testSetId)
        {
            string testInstanceUrl = _RestConnector.BuildEntityCollectionUrl("test-instance");
            string criteria = "query={cycle-id[" + testSetId + "]}";

            List<Entity> entities = SelectEntities(testInstanceUrl, criteria);

            List<TestInstance> testInstances = new List<TestInstance>();
            foreach (var entity in entities)
            {
                testInstances.Add(new TestInstance(entity));
            }

            return testInstances;
        }

        public List<TestSetFolder> GetTestSetFolders(string testLabFolderName)
        {
            string testSetFolderUrl = _RestConnector.BuildEntityCollectionUrl("test-set-folder");
            string query = "query={name[" + testLabFolderName + "]}";

            List<Entity> entities = SelectEntities(testSetFolderUrl, query);

            List<TestSetFolder> testSetFolders = new List<TestSetFolder>();
            foreach (var entity in entities)
            {
                testSetFolders.Add(new TestSetFolder(entity));
            }
            return testSetFolders;
        }

        public TestSet GetTestLab(string testLabFolderName,string parentId)
        {
            string testSetFolderUrl = _RestConnector.BuildEntityCollectionUrl("test-set-folder");
            string query = "query={name[" + testLabFolderName + "];parent-id[" + parentId + "]}";

           TestSet testSet = (TestSet)SelectEntity(testSetFolderUrl, query);

           return testSet;
        }

        private string GetTestSetFolderId(string testLabPath, string testLabFolder)
        {
            string testSetFolderUrl = _RestConnector.BuildEntityCollectionUrl("test-set-folder");
            string parentId = "0";
            string[] testLabPaths = testLabPath.Split('\\');
            foreach(string testlab in testLabPaths){
                string query = "query={name[" + testlab +"];parent-id[" + parentId + "]}";
                TestSetFolder testSetFolder = (TestSetFolder)SelectEntity(testSetFolderUrl, query);

                string testSetFolderId = testSetFolder.TestSetFolderId;
                parentId = testSetFolderId;
            }

            string queryTestLabFolderId = "query={name[" + testLabFolder + "];parent-id[" + parentId + "]}";
            TestSetFolder finalTestSetFolder = (TestSetFolder)SelectEntity(testSetFolderUrl, queryTestLabFolderId);
            string finalTestSetFolderId = finalTestSetFolder.TestSetFolderId;
            return finalTestSetFolderId;
        }

        public List<Test> GetTestPlanCases(string testPlanPath, string automationId)
        {
            List<Test> tests = new List<Test>();
            string testPlanUrl = _RestConnector.BuildEntityCollectionUrl("test");
            string parentId = "0";
            string[] testNames = testPlanPath.Split('\\');
            foreach (var testName in testNames)
            {
                string query = "query={name[" + testName + "];parent-id[" + parentId + "]}";
                Test test = (Test)SelectEntity(testPlanUrl, query);

                string testId = test.Id;
                parentId = testId;
            }
            string queryString = "query={parent-id[" + parentId +";automation-id["+automationId+ "]}";
            List<Entity> entities =  SelectEntities(testPlanUrl, queryString);
            foreach (var entity in entities)
            {
                tests.Add((Test)entity);
            }

            return tests;

        }

        public TestSet GetTestSet(string testLabPath, string testLabFolder, string testSetName)
        {
            string testSetUrl = _RestConnector.BuildEntityCollectionUrl("test-set");
            string testSetFolderId = GetTestSetFolderId(testLabPath, testLabFolder);
            string queryTestSetId = "query={name[" + testLabFolder + "];parent-id[" + testSetFolderId + "]}";

            TestSet testset = (TestSet)SelectEntity(testSetUrl, queryTestSetId);
            if (testset == null)
            {
                testset.Name= testSetName;
                string updateTestSetUrl = _RestConnector.BuildEntityCollectionUrl("test-set") + "?query={name=[" + testSetName + "]}";
                UpdateEntity(updateTestSetUrl, testset);
                return testset;
            }
            else
            {
                return testset;
            }
        }

        /// <summary>
        /// get a test by test id
        /// </summary>
        /// <param name="testId"></param>
        /// <returns>test object</returns>
        public Test GetTest(int testId)
        {
            string testUrl = _RestConnector.BuildEntityUrl("test", testId);
            Entity entity = SelectEntity(testUrl);

            return new Test(entity);
        }
        /// <summary>
        /// update a test
        /// </summary>
        /// <param name="test"></param>
        /// <returns></returns>
        public Test UpdateTest(Test test)
        {
            string entityUrl = _RestConnector.BuildEntityUrl("test", test.Id);
            Entity entity = UpdateEntity(entityUrl, test);
            return new Test(entity);
        }
        /// <summary>
        /// create a Run
        /// </summary>
        /// <param name="run"></param>
        /// <returns>a new Run</returns>
        public Run CreateRun(Run run)
        {
            string entitiesUrl = _RestConnector.BuildEntityCollectionUrl("run");
            Entity entity = CreateEntity(entitiesUrl, run);
            return new Run(entity);
        }
        /// <summary>
        /// update a run
        /// </summary>
        /// <param name="run"></param>
        /// <returns></returns>
        public Run UpdateRun(Run run)
        {
            string entitiesUrl = _RestConnector.BuildEntityUrl("run", run.Id);
            Entity entity = UpdateEntity(entitiesUrl, run);
            return new Run(entity);
        }

        /// <summary>
        /// get run steps by run id
        /// </summary>
        /// <param name="runId"></param>
        /// <returns></returns>
        public List<RunStep> GetRunSteps(int runId)
        {
            String url = _RestConnector.BuildEntityUrl("run", runId) + "/run-steps";
            List<Entity> entities = SelectEntities(url, "");

            List<RunStep> runSteps = new List<RunStep>();
            foreach (Entity entity in entities) {
                runSteps.Add(new RunStep(entity));
            }
            return runSteps;
        }

        /// <summary>
        /// create run step by providing run id.
        /// </summary>
        /// <param name="runId"></param>
        /// <param name="runStep"></param>
        /// <returns>run step</returns>
        public RunStep CreateRunStep(int runId, RunStep runStep){
            string url = _RestConnector.BuildEntityUrl("run", runId);
            Entity entity = CreateEntity(url + "/run-steps", runStep);
            return new RunStep(entity);
        }

        /// <summary>
        /// update run step
        /// </summary>
        /// <param name="runStep"></param>
        /// <returns></returns>
        public RunStep UpdateRunStep(RunStep runStep){
            String entityUrl = _RestConnector.BuildEntityUrl("run", runStep.RunId) + "/run-steps/" + runStep.Id;
            Entity entity = UpdateEntity(entityUrl, runStep);
            return new RunStep(entity);
        }
        /// <summary>
        /// create a run attachment
        /// </summary>
        /// <param name="runId"></param>
        /// <param name="fileName"></param>
        /// <param name="data"></param>
        /// <returns>attachment object</returns>
        public Attachment CreateRunAttachment(int runId, string path){
            string url = _RestConnector.BuildEntityUrl("run", runId) + "/attachments";
            Entity entity = UploadFile(url, path);
            return new Attachment(entity);
        }

        /// <summary>
        /// create run step attachment
        /// </summary>
        /// <param name="runStepId"></param>
        /// <param name="fileName"></param>
        /// <param name="data"></param>
        /// <returns>attachment object</returns>
        public Attachment CreateRunStepAttachment(int runStepId, string path){
            string url = _RestConnector.BuildEntityUrl("run-step", runStepId) + "/attachments";
            Entity entity = UploadFile(url, path);
            return new Attachment(entity);
        }

        public Attachment CreateTestSetAttachment(int testSetId, string path)
        {
            string url = _restConnector.BuildEntityUrl("test-set", testSetId) + "/attachments";
            Entity entity = UploadFile(url, path);
            return new Attachment(entity);
        }

        public Release GetRelease(string releasePath, string cycleName)
        {
            string releaseUrl = _RestConnector.BuildEntityCollectionUrl("release");
            string parentId = "0";
            string[] releasePaths = releasePath.Split('\\');
            foreach (var releaseName in releasePaths)
            {
                string query = "query={name[" + releaseName + "];parent-id[" + parentId + "]}";
                Release release = (Release)SelectEntity(releaseUrl, query);

                string releaseId = release.Id;
                parentId = releaseId;
            }

            string queryCycleId = "query={name[" + cycleName + "];parent-id[" + parentId + "]}";
            Release finalRelease = (Release)SelectEntity(releaseUrl, queryCycleId);

            return finalRelease;

        }
    }
}
