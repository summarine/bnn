﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RestSharp;
using RestSharp.Authenticators;
using System.Net;
using System.Xml.Linq;
using System.IO;


namespace ceqalib.Common.RestALM
{
    public class RestConnector
    {
        private string URL;
        private string LogoutUrl = "qcbin/authentication-point/logout";
        private string AuthenticatedUrl = "qcbin/authentication-point/authenticate";
        private string IsAuthUrl = "qcbin/rest/is-authenticated";
        private string SessionUrl = "qcbin/rest/site-session";
        private string domain;
        private string project;

        private string userId;
        private string password;

        public bool IsLogin = false;
        private Dictionary<string, string> cookies;

        private RestClient restClient = null;

        public StringBuilder log { get; set; }

        public RestConnector(string url,string domain, string project, string userId, string password)
        {
            this.URL = url;
            LogoutUrl = BuildUrl(LogoutUrl);
            AuthenticatedUrl = BuildUrl(AuthenticatedUrl);
            IsAuthUrl = BuildUrl(IsAuthUrl);
            SessionUrl = BuildUrl(SessionUrl);
            this.domain = domain;
            this.project = project;
            this.userId = userId;
            this.password = password;
            restClient = new RestClient(url);
            restClient.Authenticator = new HttpBasicAuthenticator(userId, password);
            restClient.CookieContainer = new System.Net.CookieContainer();
            restClient.ClearHandlers();
            this.cookies = new Dictionary<string, string>();
        }

        private string BuildUrl(string url)
        {
            if (URL.Contains("qcbin"))
            {
                url = url.Replace(@"qcbin/", string.Empty);
                return url;
            }
            else
            {
                return url;
            }
        }

        /// <summary>
        /// Lanuch a request whose http method is post
        /// using "POST" to change server data
        /// </summary>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <param name="headers"></param>
        /// <returns></returns>
        public IRestResponse LanuchPostRequest(string url,string data, string bodyType, Dictionary<string,string> headers)
        {
            return DoRequest(url, Method.POST, null, data, bodyType, headers, cookies);
        }

    
        /// <summary>
        /// lanuch a request whose http method is GET
        /// </summary>
        /// <param name="url"></param>
        /// <param name="queryString"></param>
        /// <param name="headers"></param>
        /// <returns></returns>
        public IRestResponse LanuchGetRequest(string url, string queryString, Dictionary<string, string> headers)
        {
            return DoRequest(url, Method.GET, queryString, null, null, headers, cookies);
        }

        /// <summary>
        /// lanuch a Request whose http method is DELETE
        /// </summary>
        /// <param name="url"></param>
        /// <param name="headers"></param>
        /// <returns></returns>
        public IRestResponse LanuchDeleteRequest(string url,  Dictionary<string, string> headers)
        {
            return DoRequest(url, Method.DELETE, null, null, null, headers, cookies);
        }

        /// <summary>
        /// lanuch a Request whose http method is PUT
        /// </summary>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <param name="headers"></param>
        /// <returns></returns>
        public IRestResponse LanuchPutRequest(string url, string data, string bodyType, Dictionary<string, string> headers)
        {
            return DoRequest(url, Method.PUT, null, data, bodyType, headers, cookies);
        }

        /// <summary>
        /// lanuch a complex request with multiple parameters
        /// </summary>
        /// <param name="url"></param>
        /// <param name="method"></param>
        /// <param name="queryString"></param>
        /// <param name="data"></param>
        /// <param name="headers"></param>
        /// <param name="cookies"></param>
        /// <returns></returns>
        private IRestResponse DoRequest(string url,Method method, string queryString,string data, string bodyType, Dictionary<string, string> headers,Dictionary<string,string> cookies)
        {
            if (queryString != null && queryString.Length > 0)
            {
                url += "/?" + queryString;
            }
            IRestRequest request = new RestRequest(url, method);
            string cookieString = GetCookieString();

            PrepareRequest(ref request, headers, data, bodyType,cookieString);
            IRestResponse response = restClient.Execute(request);
            if(response.StatusCode != HttpStatusCode.OK &&
                response.StatusCode != HttpStatusCode.Created &&
                response.StatusCode != HttpStatusCode.Accepted &&
                response.StatusCode != HttpStatusCode.Unauthorized &&
                response.StatusCode != HttpStatusCode.NoContent &&
                response.StatusCode != HttpStatusCode.ResetContent&&
                response.StatusCode != HttpStatusCode.PartialContent){
                // Exception 
                    throw new Exception("Wrong Url!");
            }
            UpdateCookies(ref response);
            return response;
        }

       

        /// <summary>
        /// get cookie details
        /// </summary>
        /// <returns></returns>
        private string GetCookieString()
        {
            StringBuilder sb = new StringBuilder();
            if (!cookies.Equals(null)){
                foreach (var cookie in cookies) {
                    sb.Append(cookie.Key).Append("=").Append(cookie.Value).Append(";");
            }
        }
            return sb.ToString();
        }

        /// <summary>
        /// update cookies
        /// </summary>
        /// <param name="response"></param>
        private void UpdateCookies(ref IRestResponse response)
        {
            List<string> newCookies = null;
            foreach(var header in response.Headers){
                if(header.ContentType =="Set-Cookie"){
                    newCookies.Add(header.Value.ToString());
                }
            }

            if (newCookies != null) {
            foreach (var cookie in newCookies) {
                int equalIndex = cookie.IndexOf('=');
                int semicolonIndex = cookie.IndexOf(';');
                string cookieKey = cookie.Substring(0, equalIndex);
                string cookieValue = cookie.Substring(equalIndex + 1, semicolonIndex);
                cookies.Add(cookieKey, cookieValue);
            }
        }
        }

        /// <summary>
        /// add some necessary parameters into a reqeust
        /// </summary>
        /// <param name="request"></param>
        /// <param name="headers"></param>
        /// <param name="bytes"></param>
        /// <param name="cookieString"></param>
        private void PrepareRequest(ref IRestRequest request, Dictionary<string, string> headers, string data,string bodyType, string cookieString)
        {
            string contentType = null;
            if (cookieString != null && cookieString.Length > 0)
            {
                request.AddCookie("Cookie", cookieString);
            }
            //Send data from headers.
            if (headers != null)
            {
                //Skip the content-type header. 
                //The content-type header should only be sent if you are sending content. See below.
                contentType = headers["Content-Type"];
                foreach(var header in headers){
                    request.AddParameter(header.Key, header.Value, ParameterType.HttpHeader);
                }
            }
            //If there is data to attach to the request, it's handled here. 
            //Note that if data exists, we take into account previously removed content-type.
            if (data != null && (data.Length >0) )
            {
                //Warning: If you add a content-type header then it is an error not to send information.
                //if (contentType != null)
                //{
                //    request.AddParameter("Content-Type", contentType);
                   
                //}
                request.AddParameter(bodyType, data, ParameterType.RequestBody);
                
            }
        }


        
        /// <summary>
        /// build an entity access url based on domain, projects and entityType
        /// </summary>
        /// <param name="entityType"></param>
        /// <returns>a url</returns>
        public string BuildEntityCollectionUrl(string entityType)
        {
            return string.Format("rest/domains/{0}/projects/{1}/{2}s", domain, project, entityType);
        }

        /// <summary>
        /// build an specific entity access url based on entityType and entity id which type is string
        /// </summary>
        /// <param name="entityType"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public string BuildEntityUrl(string entityType, string id)
        {
            return BuildEntityCollectionUrl(entityType) + "/" + id;
        }

        /// <summary>
        /// build an specific entity access url based on entityType and entity id which type is int
        /// </summary>
        /// <param name="entityType"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public string BuildEntityUrl(string entityType, int id)
        {
            return BuildEntityCollectionUrl(entityType) + "/" + id;
        }

        /// <summary>
        /// see if the user is authenticated.
        /// </summary>
        /// <returns>return a url of authorization if the user is not authenticated</returns>
        public string IsAuthenticated()
        {
            IRestRequest authRequest = new RestRequest(IsAuthUrl);
            //CleanRequest(ref isAuthenticated);
            IRestResponse authResponse = restClient.Execute(authRequest);

            if (authResponse.StatusCode == HttpStatusCode.Unauthorized || authResponse.StatusCode != HttpStatusCode.OK)
            {
                return AuthenticatedUrl;
            }
            else
            {
                return null;
            }
               
        }

        /// <summary>
        /// go to authentication point when the first authenticated.
        /// if not the first authenticated, then login.
        /// </summary>
        /// <returns>true if login</returns>
        public bool Login()
        {
            string authenticationPoint = this.IsAuthenticated();
            if (authenticationPoint != null)
            {
              IsLogin = Login(authenticationPoint);
            }
            else
            {
                IsLogin = Login(URL);
            }
            return IsLogin;
        }

        /// <summary>
        /// login the QualityCenter
        /// </summary>
        /// <param name="loginUrl"></param>
        /// <returns>return response.StatusCode == HttpStatusCode.OK</returns>
        private bool Login(string loginUrl)
        {
            IRestResponse response = null;
            //connect to quality center
            //login --start a login request
           
            IRestRequest loginRequest = new RestRequest(loginUrl);

            response = restClient.Execute(loginRequest);
            if (response.StatusCode == HttpStatusCode.OK)
            {
                //setup session
                SetupSession();
                return true;
            }      
            return response.StatusCode == HttpStatusCode.OK;
        }

        /// <summary>
        /// create a session when login.
        /// </summary>
        private void SetupSession()
        {
            IRestRequest sessionRequest = new RestRequest(SessionUrl,Method.POST);
            restClient.Execute(sessionRequest);
        }
        /// <summary>
        /// close session when logout
        /// </summary>
        private void closeSession()
        {
            IRestRequest sessionRequest = new RestRequest(SessionUrl, Method.DELETE);
            restClient.Execute(sessionRequest);
        }


        /// <summary>
        /// logout QualityCenter
        /// </summary>
        /// <returns>return response.StatusCode == HttpStatusCode.OK</returns>
        public bool Logout()
        {
            IRestRequest logoutRequest = new RestRequest(LogoutUrl);

            //CleanRequest(ref logoutRequest);
            IRestResponse response = restClient.Execute(logoutRequest);

            return (response.StatusCode == HttpStatusCode.OK);
        }


    }
}
