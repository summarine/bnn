﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace ceqalib.Common.Helper
{
    /// <summary>
    /// SingleTon xmlHelper
    /// </summary>
    public sealed class XmlHelper
    {
        private static readonly XmlHelper instance = new XmlHelper();
        private XmlSerializer xmlSerializer = null;

        private XmlHelper()
        {

        }

        public static XmlHelper Instance
        {
            get
            {
                return instance;
            }
        }
        /// <summary>
        /// serializer the object to xml string
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public string ToXml(object obj )
        {
            if (obj == null)
            {
                return null;
            }
            try
            {
                //delete the <xml = "">
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.OmitXmlDeclaration = true;
                xmlSerializer = new XmlSerializer(obj.GetType().BaseType);
                
                XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
                ns.Add("","");
                var stringWriter = new StringWriter();
                using (var writer = XmlWriter.Create(stringWriter,settings))
                {
                    xmlSerializer.Serialize(writer, obj,ns);
                    return stringWriter.ToString();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            
        }

        /// <summary>
        /// deserializer the xml to an object 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="path"></param>
        /// <returns></returns>
        public T FromXml<T>(string data)
        {
            T objs;
            if (string.IsNullOrEmpty(data))
            {
                return default(T);
            }
            try
            {
                xmlSerializer = new XmlSerializer(typeof(T));
                
                using (TextReader reader = new StringReader(data))
                {
                    objs =(T)xmlSerializer.Deserialize(reader);
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return objs;
        }
    }
}
